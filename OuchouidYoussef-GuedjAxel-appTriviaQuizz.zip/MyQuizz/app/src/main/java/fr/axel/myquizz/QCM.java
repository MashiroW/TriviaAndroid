package fr.axel.myquizz;

import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Objects;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import java.lang.*;


public class QCM extends AppCompatActivity {

    private Button Answer_A;
    private Button Answer_B;
    private Button Answer_C;
    private Button Answer_D;
    private TextView question_field;
    private TextView listAnswers;
    String CurrentQuestion = "";

    JSONArray results = new JSONArray();
    JSONObject res = new JSONObject();

    int QuestionIndex = 0;
    String Answer = "None";

    String url = "https://opentdb.com/api.php?amount=10&type=multiple";

    void set_question(String s)
    {
        this.CurrentQuestion = s;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_qcm);

        listAnswers = findViewById(R.id.listAnswers); //VIEWER DE LA QUESTION
        question_field = findViewById(R.id.question_field); //VIEWER DE LA QUESTION
        fetch_data();

        try {
            System.out.println(results);
            question_field = findViewById(R.id.question_field); //VIEWER DE LA QUESTION
            CurrentQuestion = results.getJSONObject(QuestionIndex).get("question").toString();
            question_field.setText(Html.fromHtml(CurrentQuestion, Html.FROM_HTML_MODE_COMPACT));
        }

        catch (JSONException e) {
            e.printStackTrace();
        }

        //question_field.setText(Html.fromHtml(CurrentQuestion, Html.FROM_HTML_MODE_COMPACT));
        listAnswers.setText(Html.fromHtml(CurrentQuestion, Html.FROM_HTML_MODE_COMPACT));

    }

    void fetch_data()
    {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback()
        {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }


            @Override
            public void onResponse(@NotNull Call call, @NotNull okhttp3.Response response) throws IOException {
                Log.d("test", String.valueOf(response.isSuccessful()));
                if (response.isSuccessful()) {
                    String myResponse = Objects.requireNonNull(response.body()).string();


                    try {
                        JSONObject obj = new JSONObject(myResponse);
                        results = obj.getJSONArray("results");

                        res = results.getJSONObject(QuestionIndex);

                        CurrentQuestion = res.get("question").toString();
                        Answer = res.get("correct_answer").toString();
                        System.out.println(CurrentQuestion);
                        set_question(CurrentQuestion);

                        question_field.setText(Html.fromHtml(CurrentQuestion, Html.FROM_HTML_MODE_COMPACT));
                        System.out.println(res.getJSONArray("incorrect_answers").get(0).toString());



                        String test = ("A- ").concat(res.getJSONArray("incorrect_answers").get(0).toString()).concat(" B- ").concat(res.getJSONArray("incorrect_answers").get(1).toString()).concat(" C- ").concat(res.getJSONArray("incorrect_answers").get(2).toString()).concat(" D- ").concat(Answer);
                        listAnswers.setText(Html.fromHtml(test, Html.FROM_HTML_MODE_COMPACT));

                        //listAnswers.setText(Html.fromHtml("OUIIIIIIIIIIIIIIIIII", Html.FROM_HTML_MODE_COMPACT));

                    }

                    catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }
        });
    }
}