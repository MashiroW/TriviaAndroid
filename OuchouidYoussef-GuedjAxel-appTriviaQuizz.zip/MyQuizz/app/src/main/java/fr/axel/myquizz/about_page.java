package fr.axel.myquizz;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Objects;

import okhttp3.Call;


public class about_page extends AppCompatActivity {
    private Button leave_button;

    String CurrentQuestion = "None";
    int QuestionIndex = 0;
    int Score = 0;

    String Answer = "None";

    JSONArray results = new JSONArray();
    JSONObject res = new JSONObject();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_about);


        leave_button = (Button) findViewById(R.id.leave3);
        leave_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back_menu();
            }
        });
 /*

        public void onResponse(@NotNull Call call, @NotNull okhttp3.Response response) throws IOException {
            Log.d("test", String.valueOf(response.isSuccessful()));
            if (response.isSuccessful()) {
                String myResponse = Objects.requireNonNull(response.body()).string();

                try {
                    System.out.println("---------- LISTE DES QUESTIONS ----------");


                    JSONObject obj = new JSONObject(myResponse);
                    results = obj.getJSONArray("results");
                    res = results.getJSONObject(QuestionIndex);

                    CurrentQuestion = res.get("question").toString();
                    Answer = res.get("correct_answer").toString();
                    System.out.println(CurrentQuestion);

                }

                catch (JSONException e) {
                    System.out.println("-- FAIL DE LA RECUPERATION --");
                    e.printStackTrace();
                }

            }


        }*/
    }

    public void back_menu() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}