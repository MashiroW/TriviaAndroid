package fr.axel.myquizz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button button_start;
    private Button button_about;
    private Button button_startQCM;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_start = (Button) findViewById(R.id.button_start);
        button_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start_quizz();
            }
        });

        button_about = (Button) findViewById(R.id.button_about);
        button_about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start_about();
            }
        });

        button_startQCM = (Button) findViewById(R.id.button_startQCM);
        button_startQCM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start_QCM();
            }
        });


        }
    public void start_quizz() {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

    public void start_about() {
        Intent intent2 = new Intent(this, about_page.class);
        startActivity(intent2);
    }

    public void start_QCM() {
        Intent intent2 = new Intent(this, QCM.class);
        startActivity(intent2);
    }
}