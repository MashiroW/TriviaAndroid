package fr.axel.myquizz;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;


public class scoreboard extends AppCompatActivity {

    private TextView ScoreTextView;
    private TextView BestScoreTextView;
    private TextView BestScoreSentenceTextView;
    int LastScore;
    int BestScore;

    private Button leave_button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_scoreboard);

        leave_button = (Button) findViewById(R.id.leave);
        leave_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back_menu();
            }
        });


        Bundle extras = getIntent().getExtras();
        LastScore = extras.getInt("LastScore");
        System.out.println(LastScore);


        ScoreTextView = findViewById(R.id.LastScore); //VIEWER DU SCORE
        ScoreTextView.setText(String.valueOf(LastScore)); //AFFICHER LE SCORE


        try {
            JSONObject obj = new JSONObject(loadJSONFromAsset());
            BestScore = obj.getInt("best_score");
            System.out.println(BestScore);
        }
        catch (JSONException e) {
            System.out.println("-- FAIL DE LA RECUPERATION --");
            e.printStackTrace();
        }

        BestScoreTextView = findViewById(R.id.bestscore); //VIEWER DU SCORE
        BestScoreTextView.setText(String.valueOf(BestScore)); //AFFICHER LE SCORE

        if ( BestScore < LastScore ){
            BestScoreSentenceTextView = findViewById(R.id.HighScoreSentence); //VIEWER DU SCORE
            BestScoreSentenceTextView.setText("NEW HIGH SCORE !"); //AFFICHER LE SCORE

            try {
                JSONObject js = new JSONObject(loadJSONFromAsset());

                js.remove("best_score"); // Since you want to replace the value associated with id, remove it
                js.put("best_score", LastScore); // add the new value for id
            }
            catch (JSONException e) {
                System.out.println("-- FAIL DE LA RECUPERATION --");
                e.printStackTrace();
            }
        }

    }


    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = this.getAssets().open("dataset.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public void back_menu() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}