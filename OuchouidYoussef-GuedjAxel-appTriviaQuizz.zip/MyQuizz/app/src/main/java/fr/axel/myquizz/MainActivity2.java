package fr.axel.myquizz;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;


import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;

import com.android.volley.RequestQueue;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;


public class MainActivity2 extends AppCompatActivity {

    private TextView mTextViewResult;
    private Button trueAnswer;
    private Button falseAnswer;
    private RequestQueue mQueue;
    public String url = "https://opentdb.com/api.php?amount=10&type=boolean";


    private TextView ScoreTextView;
    String CurrentQuestion = "None";
    int QuestionIndex = 0;
    int Score = 0;

    String Answer = "None";

    JSONArray results = new JSONArray();
    JSONObject res = new JSONObject();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        // BOUTON TRUE CHANGE L'INDEX DE LA QUESTION
        trueAnswer = (Button) findViewById(R.id.trueAnswer);
        trueAnswer.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override public void onClick(View v) {
                //Treating current answer

                System.out.println(Answer);
                System.out.println(CurrentQuestion);

                if (Answer.equals("True")) {
                    Score += 1;
                }
                else {
                   Score -= 1;
                }

                ScoreTextView.setText(String.valueOf(Score)); //AFFICHER LE SCORE

                //Getting the next question ready
                if (QuestionIndex != results.length() -1){

                    QuestionIndex += 1;

                    try {
                        res = results.getJSONObject(QuestionIndex);
                        CurrentQuestion = res.get("question").toString();
                        Answer = res.get("correct_answer").toString();
                        //mTextViewResult.setText(Html.fromHTML(CurrentQuestion, Html.FROM_HTML_MODE_COMPACT));
                        mTextViewResult.setText(Html.fromHtml(CurrentQuestion, Html.FROM_HTML_MODE_COMPACT));
                    }

                    catch (JSONException e) {
                        System.out.println("-- FAIL BOUTON TRUE --");
                        e.printStackTrace();
                    }
                }

                else{
                    System.out.println("QUESTIONS OVER");


                    Intent i = new Intent(getApplicationContext(), scoreboard.class);
                    i.putExtra("LastScore", Score);
                    startActivity(i);


                    /*
                    try {
                        JSONObject js = new JSONObject(loadJSONFromAsset());

                        js.remove("user_score"); // Since you want to replace the value associated with id, remove it
                        js.put("user_score", Score); // add the new value for id
                    }
                    catch (JSONException e) {
                        System.out.println("-- FAIL DE LA RECUPERATION --");
                        e.printStackTrace();
                    }*/


                    endgame();
                }
            }
        });

        // BOUTON FALSE CHANGE L'INDEX DE LA QUESTION
        falseAnswer = (Button) findViewById(R.id.falseAnswer);
        falseAnswer.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override public void onClick(View v) {
                //Treating current answer

                System.out.println(Answer);
                System.out.println(CurrentQuestion);

                if (Answer.equals("False")) {
                    Score += 1;
                }
                else {
                    Score -= 1;
                }

                ScoreTextView.setText(String.valueOf(Score)); //AFFICHER LE SCORE

                //Getting the next question ready
                if (QuestionIndex != results.length() -1){

                    QuestionIndex += 1;

                    try {
                        res = results.getJSONObject(QuestionIndex);
                        CurrentQuestion = res.get("question").toString();
                        Answer = res.get("correct_answer").toString();
                        //mTextViewResult.setText(Html.fromHTML(CurrentQuestion, Html.FROM_HTML_MODE_COMPACT));
                        mTextViewResult.setText(Html.fromHtml(CurrentQuestion, Html.FROM_HTML_MODE_COMPACT));
                    }

                    catch (JSONException e) {
                        System.out.println("-- FAIL BOUTON False --");
                        e.printStackTrace();
                    }
                }

                else{
                    System.out.println("QUESTIONS OVER");

                    Intent i = new Intent(getApplicationContext(), scoreboard.class);
                    i.putExtra("LastScore", Score);
                    startActivity(i);

                    endgame();
                }
            }
        });

        mTextViewResult = findViewById(R.id.txtresultapi); //VIEWER DE LA QUESTION
        ScoreTextView = findViewById(R.id.LastScore); //VIEWER DU SCORE

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {

            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull okhttp3.Response response) throws IOException {
                Log.d("test", String.valueOf(response.isSuccessful()));
                if (response.isSuccessful()) {
                      String myResponse = Objects.requireNonNull(response.body()).string();

                   try {
                       System.out.println("---------- LISTE DES QUESTIONS ----------");

                        /*
                       JSONObject obj = new JSONObject (myResponse);
                       JSONArray results = obj.getJSONArray("results");


                       for (int i = 0; i < results.length(); ++i) {
                           JSONObject res = results.getJSONObject(i);
                           CurrentQuestion = res.get("question").toString();
                           System.out.println(CurrentQuestion);
                       }
                       */

                       JSONObject obj = new JSONObject(myResponse);
                       results = obj.getJSONArray("results");
                       res = results.getJSONObject(QuestionIndex);

                       CurrentQuestion = res.get("question").toString();
                       Answer = res.get("correct_answer").toString();
                       System.out.println(CurrentQuestion);

                   }

                   catch (JSONException e) {
                       System.out.println("-- FAIL DE LA RECUPERATION --");
                       e.printStackTrace();
                   }


                    MainActivity2.this.runOnUiThread(new Runnable() {
                        @RequiresApi(api = Build.VERSION_CODES.N)
                        @Override
                        public void run() {
                            mTextViewResult.setText(Html.fromHtml(CurrentQuestion, Html.FROM_HTML_MODE_COMPACT));
                        }
                    });
                }
            }
        });

    }

    private void endgame() {
        startActivity(new Intent(getApplicationContext(), scoreboard.class));
    }

    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = this.getAssets().open("dataset.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public String geturl(){
        return url;
    }
}
